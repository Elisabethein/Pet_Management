export interface Pet{
    id:number;
    name: string;
    code: number;
    type: string;
    fur: string;
    origin: string;
}